const photo = document.getElementById('profile-photo');
if (photo) {
  photo.addEventListener('error', () => { photo.hidden = true; });
  if (photo.complete && photo.naturalWidth === 0) photo.hidden = true;
}
const year = document.getElementById('year');
if (year) year.textContent = new Date().getFullYear();
